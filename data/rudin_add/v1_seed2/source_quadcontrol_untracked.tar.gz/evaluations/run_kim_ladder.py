#!/usr/bin/env python3
"""Directional survival ladder for the Kim (MPC + WBIC) arm.

The Rudin/ours ladder lives in run_one_ladder.py and is hardcoded to an RL
checkpoint; Kim is a native binary with no model path, evaluates under the tag
"wbic", and can use the isolated parallel workers added in quadcontrol@285ae9d.
Rather than bend the RL driver into a shape that fits both, this is its
sibling: same rung schedule, same stopping rule, same protocol flags.

PARALLELISM. --workers N gives each simulator instance its own LogServer UDP
port (from --port-base) and its own CSV path, and the sweep then bypasses the
shared simulator lock. That bypass is only sound because the instances share
no file or socket; a matched-seed serial/parallel validation on fwd 2.5 m/s
(seed 42, n=25) reproduced the serial survival vector episode-for-episode
before this driver was used for any archival data.

PROTOCOL. Matches how the ours and rudin arms were measured: a velocity kick
with "add" semantics in the body_latched_at_onset frame, force seed 42, and
per-episode initial-state randomisation. Scoring is common_fall_v1.
"""
import argparse
import csv
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path

HERE = Path(__file__).resolve().parent
BASE_RUNGS = "0.5,1.0,1.5,2.0,2.5,3.0,3.5"
EXT_RUNGS = "4.0,4.5,5.0"
CEILING = 10.0           # simulator safety ceiling
DIRS = ("fwd", "back", "left", "right", "up", "down")
COMMON = ["--controllers", "kim", "--disturbance", "velocity",
          "--push-semantics", "add", "--force-frame", "body_latched_at_onset",
          "--seed", "42"]

RUN_DIR = ""
RUNS = 25
WORKERS = 25
PORT_BASE = 5600


def log(msg: str) -> None:
    print(f"[{datetime.now().isoformat(timespec='seconds')}] {msg}", flush=True)


def cell_name(direction: str, magnitude: float) -> str:
    return f"{direction}_{('%g' % magnitude).replace('.', 'p')}mps"


def sweep(dirs: str, rungs: str, *extra: str) -> None:
    """One run.py sweep, with a single retry on a flaky native teardown."""
    cmd = [sys.executable, "run.py", "sweep", *COMMON,
           "--runs", str(RUNS), "--trace-runs", "1",
           "--wbic-workers", str(WORKERS), "--wbic-port-base", str(PORT_BASE),
           "--dirs", dirs, "--impulses", rungs,
           "--run-dir", RUN_DIR, *extra]
    for attempt in (1, 2):
        r = subprocess.run(cmd, cwd=HERE, capture_output=True, text=True)
        if r.returncode == 0:
            return
        blob = (r.stdout or "") + (r.stderr or "")
        if attempt == 1:
            log(f"cell failed (rc={r.returncode}); pausing 60 s and retrying once")
            time.sleep(60)
            continue
        log(f"FAILED rc={r.returncode}: {' '.join(cmd)}")
        log(blob[-2000:])
        raise SystemExit(1)


def survivors(direction: str, magnitude: float) -> int | None:
    path = (HERE / "results" / RUN_DIR / "wbic"
            / cell_name(direction, magnitude) / "summary.csv")
    if not path.exists():
        return None
    with path.open() as fh:
        return sum(int(row["survived"]) for row in csv.DictReader(fh))


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--run-dir", required=True, help="results folder name")
    ap.add_argument("--runs", type=int, default=25, help="episodes per cell")
    ap.add_argument("--workers", type=int, default=25,
                    help="concurrent isolated simulator instances")
    ap.add_argument("--port-base", type=int, default=5600)
    a = ap.parse_args()

    global RUN_DIR, RUNS, WORKERS, PORT_BASE
    RUN_DIR, RUNS = a.run_dir, a.runs
    WORKERS, PORT_BASE = a.workers, a.port_base

    log(f"=== kim ladder -> {RUN_DIR}  ({RUNS} runs/cell, {WORKERS} workers)")
    log(f"=== base sweep {BASE_RUNGS} (with the no-kick control cell)")
    sweep(",".join(DIRS), BASE_RUNGS, "--skip-existing")
    log(f"=== extension {EXT_RUNGS}")
    sweep(",".join(DIRS), EXT_RUNGS, "--no-noforce", "--skip-existing")

    stops = {}
    for d in DIRS:
        mag = 5.0
        while True:
            n = survivors(d, mag)
            if n is None:
                log(f"{d}: cell at {mag} m/s missing; stopping this direction")
                stops[d] = f"{mag} (cell missing)"
                break
            if n == 0:
                log(f"{d}: 0/{RUNS} survived at {mag} m/s -- done")
                stops[d] = f"{mag} (0/{RUNS})"
                break
            if mag >= CEILING:
                log(f"{d}: CEILING -- {n}/{RUNS} still survive at {CEILING} m/s")
                stops[d] = f"{CEILING} CEILING, {n}/{RUNS} alive"
                break
            mag = round(mag + 0.5, 1)
            log(f"{d}: survivors below, climbing to {mag} m/s")
            sweep(d, str(mag), "--no-noforce", "--skip-existing")
    log("=== LADDER COMPLETE: " + "  ".join(f"{d}={v}" for d, v in stops.items()))


if __name__ == "__main__":
    main()
