#!/usr/bin/env python3
"""Rudin HEIGHT-ENFORCED arm, v1 velocity-kick evaluation -- three seeds.

Same protocol as run_rudin_eval.py, pointed at the warm-started height arm
(base-height scale -30, target 0.30 m). Queued behind run_height_warmstart.sh.

Protocol-matched to the Kim and Ours evaluations running on the other machines:
same seed (42), cells, disturbance, semantics, frame, onset and run count. Two
deviations are forced by this arm and cannot be flagged away:

  * --survival-only is mandatory for rsl_rl checkpoints (core/_rl_eval.py:475).
  * Therefore NO traces are archived (--trace-runs is inert) and the journal
    tracking/torque/CoT columns stay empty. Under RL the MPC never runs, so
    those metrics are structurally NaN for this arm anyway.

Waits for the training chain to finish, then evaluates each seed in its own
results directory. Sequential throughout: LogServer UDP 5500 and the simulator
lock are singletons.
"""

from __future__ import annotations

import csv
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from core.forces import cell_name_for  # noqa: E402

SEEDS = (1, 2, 3)
HOST_RUNS = Path("/home/tarik/quadruped_ws/envpool/data/rudin_height_ws")
MODEL = "/app/envpool/data/rudin_height_ws/v1_seed{s}/model_500.pt"
RUN_DIR = "20260913_rudinheight_v1_seed{s}_n100"
BASE_RUNGS = "0.5,1.0,1.5,2.0,2.5,3.0,3.5"
EXT_RUNGS = "4.0,4.5,5.0"
CEILING = 10.0           # simulator safety ceiling
DIRS = ("fwd", "back", "left", "right", "up", "down")
COMMON = ["--controllers", "rudin", "--disturbance", "velocity",
          "--push-semantics", "set", "--force-frame", "body_latched_at_onset",
          "--seed", "42", "--runs", "100", "--survival-only"]


def log(msg: str) -> None:
    print(f"[{datetime.now().isoformat(timespec='seconds')}] {msg}", flush=True)


def sweep(seed: int, dirs: str, rungs: str, *extra: str) -> None:
    """One run.py sweep. Retries while the simulator lock is held elsewhere."""
    cmd = [sys.executable, "run.py", "sweep", *COMMON,
           "--rl-model-rudin", MODEL.format(s=seed),
           "--dirs", dirs, "--impulses", rungs,
           "--run-dir", RUN_DIR.format(s=seed), *extra]
    while True:
        r = subprocess.run(cmd, cwd=HERE, capture_output=True, text=True)
        if r.returncode == 0:
            return
        blob = (r.stdout or "") + (r.stderr or "")
        if "LockBusy" in blob or "simulator lock" in blob.lower():
            log("simulator lock busy; waiting 120 s")
            time.sleep(120)
            continue
        log(f"FAILED rc={r.returncode}: {' '.join(cmd)}")
        log(blob[-2000:])
        raise SystemExit(1)


def survivors(seed: int, direction: str, magnitude: float) -> int | None:
    """Count survived=1 rows in a cell, or None if the cell is absent."""
    path = (HERE / "results" / RUN_DIR.format(s=seed) / "rl_rudin"
            / cell_name_for(direction, magnitude, "mps") / "summary.csv")
    if not path.exists():
        return None
    with path.open() as fh:
        return sum(int(row["survived"]) for row in csv.DictReader(fh))


def wait_for_training() -> None:
    log("waiting for the training chain to finish")
    while subprocess.run(["pgrep", "-f", "[t]rain_unitree.py"],
                         capture_output=True).returncode == 0:
        time.sleep(120)
    while subprocess.run(["pgrep", "-f", "[r]un_height_warmstart.sh"],
                         capture_output=True).returncode == 0:
        time.sleep(120)
    log("training chain is done")


def main() -> None:
    wait_for_training()
    ready = [s for s in SEEDS if (HOST_RUNS / f"v1_seed{s}" / "model_500.pt").is_file()]
    missing = [s for s in SEEDS if s not in ready]
    if missing:
        log(f"WARNING: no model_1500.pt for seed(s) {missing}; evaluating {ready} only")
    if not ready:
        log("no finished models; nothing to evaluate")
        raise SystemExit(1)

    stops: dict[int, dict[str, str]] = {}
    for seed in ready:
        log(f"=== seed {seed}: base sweep {BASE_RUNGS} (with the no-kick control cell)")
        sweep(seed, ",".join(DIRS), BASE_RUNGS, "--skip-existing")
        log(f"=== seed {seed}: extension {EXT_RUNGS}")
        sweep(seed, ",".join(DIRS), EXT_RUNGS, "--no-noforce", "--skip-existing")

        stops[seed] = {}
        for d in DIRS:
            mag = 5.0
            while True:
                n = survivors(seed, d, mag)
                if n is None:
                    log(f"seed {seed} {d}: cell at {mag} m/s missing; stopping this direction")
                    stops[seed][d] = f"{mag} (cell missing)"
                    break
                if n == 0:
                    log(f"seed {seed} {d}: 0/100 survived at {mag} m/s -- done")
                    stops[seed][d] = f"{mag} (0/100)"
                    break
                if mag >= CEILING:
                    log(f"seed {seed} {d}: CEILING -- {n}/100 still survive at {CEILING} m/s")
                    stops[seed][d] = f"{CEILING} CEILING, {n}/100 alive"
                    break
                mag = round(mag + 0.5, 1)
                log(f"seed {seed} {d}: survivors below, climbing to {mag} m/s")
                sweep(seed, d, str(mag), "--no-noforce", "--skip-existing")
        log(f"=== seed {seed} complete: {stops[seed]}")

    log("=== RUDIN EVALUATION COMPLETE ===")
    for seed, per_dir in stops.items():
        log(f"seed {seed}: " + "  ".join(f"{d}={v}" for d, v in per_dir.items()))


if __name__ == "__main__":
    main()
