#include "modules/MdlRLJointPD.hh"

#include <algorithm>
#include <cmath>

#include "control/ControlMessages.hh"
#include "modules/MdlLegController.hh"
#include "modules/MdlRLCommandSource.hh"
#include "rtcore/ConfigTable.hh"
#include "rtcore/ModuleManager.hh"

namespace quadruped {
namespace {
constexpr float kDegToRad = 0.01745329251994329577f;
constexpr float kSideSign[4] = {-1.0f, 1.0f, -1.0f, 1.0f};
}  // namespace

MdlRLJointPD::MdlRLJointPD() : Module(RLJOINTPD_NAME, 0, MULTI_USER) {}

void MdlRLJointPD::init() {
  resetPolicyAction();
  resolveModules_();
  loadConfig_();
  _logserver = dynamic_cast<rtcore::LogServer*>(
      _mgr->findModule(LOGSERVER_NAME, 0));
  registerLogs_();
}

void MdlRLJointPD::uninit() {
  unregisterLogs_();
  _logserver = nullptr;
  _leg_controller = nullptr;
  _command_source = nullptr;
}

void MdlRLJointPD::activate() {
  resetPolicyAction();
  resolveModules_();
  if (!_config_loaded) loadConfig_();
  if (!_logserver) {
    _logserver = dynamic_cast<rtcore::LogServer*>(
        _mgr->findModule(LOGSERVER_NAME, 0));
    registerLogs_();
  }
}

void MdlRLJointPD::deactivate() { resetPolicyAction(); }

void MdlRLJointPD::setPolicyAction(
    const std::array<float, kActionDim>& action, std::size_t count) {
  _action.fill(0.0f);
  const std::size_t n = std::min(count, kActionDim);
  for (std::size_t i = 0; i < n; ++i) {
    _action[i] = std::isfinite(action[i]) ? action[i] : 0.0f;
  }
}

void MdlRLJointPD::resetPolicyAction() { _action.fill(0.0f); }

void MdlRLJointPD::update() {
  resolveModules_();
  if (!_leg_controller) return;

  LegCommand command{};
  command.reset();
  command.source_mode = ControlMode::kRlLocomotion;
  command.timestamp = _mgr ? _mgr->readTime() : 0.0;
  for (int leg = 0; leg < 4; ++leg) {
    auto& leg_command = command.commands[leg];
    leg_command.tauFeedForward.setZero();
    leg_command.forceFeedForward.setZero();
    leg_command.qdDes.setZero();
    leg_command.kpJoint = Vec3<float>(_kp, _kp, _kp).asDiagonal();
    leg_command.kdJoint = Vec3<float>(_kd, _kd, _kd).asDiagonal();
    for (int joint = 0; joint < 3; ++joint) {
      const int axis = leg * 3 + joint;
      const float q_des = _q_default[axis] + _action_scale * _action[axis];
      leg_command.qDes[joint] = q_des;
      _log_q_des[axis] = q_des;
    }
  }
  if (_command_source) {
    const auto& desired = _command_source->desiredVelocity().body_velocity;
    for (int i = 0; i < 3; ++i) _log_cmd_vel[i] = desired[i];
  } else {
    std::fill_n(_log_cmd_vel, 3, 0.0f);
  }
  _leg_controller->setLegCommand(command);
}

void MdlRLJointPD::resolveModules_() {
  if (!_mgr) return;
  if (!_leg_controller) {
    _leg_controller = dynamic_cast<MdlLegController*>(
        _mgr->findModule(LEGCONTROLLER_NAME, 0));
  }
  if (!_command_source) {
    _command_source = dynamic_cast<MdlRLCommandSource*>(
        _mgr->findModule(RLCOMMANDSOURCE_NAME, 0));
  }
}

void MdlRLJointPD::loadConfig_() {
  float angles_deg[3] = {10.0f, -50.0f, 90.0f};
  bool have_default_joint_positions = false;
  if (_mgr) {
    rtcore::ConfigTable sim;
    rtcore::ConfigArray values;
    if (_mgr->getConfigTable("simulation", sim) &&
        sim.getArray("initial_leg_joint_deg", values) && values.size() >= 3) {
      for (int joint = 0; joint < 3; ++joint) {
        angles_deg[joint] =
            static_cast<float>(values.getDoubleAt(joint, angles_deg[joint]));
      }
    }
    rtcore::ConfigTable config;
    if (_mgr->getConfigTable("rl_joint_pd", config)) {
      _kp = static_cast<float>(config.getDouble("stiffness", _kp));
      _kd = static_cast<float>(config.getDouble("damping", _kd));
      _action_scale =
          static_cast<float>(config.getDouble("action_scale", _action_scale));
      rtcore::ConfigArray defaults;
      if (config.getArray("default_joint_positions", defaults) &&
          defaults.size() == kActionDim) {
        for (std::size_t axis = 0; axis < kActionDim; ++axis) {
          _q_default[axis] =
              static_cast<float>(defaults.getDoubleAt(axis, 0.0));
        }
        have_default_joint_positions = true;
      }
    }
  }
  if (have_default_joint_positions) {
    _config_loaded = true;
    return;
  }
  for (int leg = 0; leg < 4; ++leg) {
    _q_default[leg * 3] = kSideSign[leg] * angles_deg[0] * kDegToRad;
    _q_default[leg * 3 + 1] = angles_deg[1] * kDegToRad;
    _q_default[leg * 3 + 2] = angles_deg[2] * kDegToRad;
  }
  _config_loaded = true;
}

void MdlRLJointPD::registerLogs_() {
  if (!_logserver || _log_ids[0]) return;
  _log_ids[0] = _logserver->registerVar(
      rtcore::LOG_FLOAT, 3, RLJOINTPD_NAME, "cmd_vel",
      reinterpret_cast<unsigned char*>(_log_cmd_vel));
  _log_ids[1] = _logserver->registerVar(
      rtcore::LOG_FLOAT, kActionDim, RLJOINTPD_NAME, "q_des",
      reinterpret_cast<unsigned char*>(_log_q_des));
}

void MdlRLJointPD::unregisterLogs_() {
  if (!_mgr || _mgr->findModule(LOGSERVER_NAME, 0) != _logserver) {
    _logserver = nullptr;
  }
  if (!_logserver) {
    std::fill_n(_log_ids, 2, 0);
    return;
  }
  for (auto& id : _log_ids) {
    if (id) _logserver->deleteVar(id);
    id = 0;
  }
}

}  // namespace quadruped
