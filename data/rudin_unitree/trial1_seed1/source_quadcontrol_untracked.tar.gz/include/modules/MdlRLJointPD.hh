/*
 * End-to-end RL joint-position command module.
 */

#ifndef QUADRUPED_MDLRLJOINTPD_HH
#define QUADRUPED_MDLRLJOINTPD_HH

#include <array>
#include <cstddef>

#include "rtcore/LogServer.hh"
#include "rtcore/Module.hh"

namespace quadruped {

#define RLJOINTPD_NAME "MdlRLJointPD"

class MdlLegController;
class MdlRLCommandSource;

class MdlRLJointPD : public rtcore::Module {
 public:
  static constexpr std::size_t kActionDim = 12;

  MdlRLJointPD();
  ~MdlRLJointPD() override = default;

  void init() override;
  void uninit() override;
  void activate() override;
  void deactivate() override;
  void update() override;

  void setPolicyAction(const std::array<float, kActionDim>& action,
                       std::size_t count);
  void resetPolicyAction();
  const std::array<float, kActionDim>& defaultJointPosition() const {
    return _q_default;
  }

 private:
  void resolveModules_();
  void loadConfig_();
  void registerLogs_();
  void unregisterLogs_();

  MdlLegController* _leg_controller = nullptr;
  MdlRLCommandSource* _command_source = nullptr;
  rtcore::LogServer* _logserver = nullptr;

  std::array<float, kActionDim> _action{};
  std::array<float, kActionDim> _q_default{};
  float _kp = 20.0f;
  float _kd = 0.5f;
  float _action_scale = 0.25f;
  bool _config_loaded = false;

  uintptr_t _log_ids[2] = {};
  float _log_cmd_vel[3] = {};
  float _log_q_des[kActionDim] = {};
};

}  // namespace quadruped

#endif  // QUADRUPED_MDLRLJOINTPD_HH
