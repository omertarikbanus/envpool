# Vendored: rsl_rl v1.0.2 (unmodified)

Source: https://github.com/leggedrobotics/rsl_rl, tag `v1.0.2`,
commit `2ad79cf0caa85b91721abfe358105f869a784121` (2022-03-14).
License: BSD-3-Clause, see `LICENSE` (ETH Zurich / NVIDIA).

This is the exact version `unitreerobotics/unitree_rl_gym` pins
(`doc/setup_en.md`: `git checkout v1.0.2`). It is vendored rather than
pip-installed so the trainer for the Rudin arm runs the reference PPO
bit-for-bit, and so the container needs no extra install.

**Do not edit these files.** Adapt the environment side instead
(`examples/common/rsl_vec_env.py`). Verify integrity with:

    cd examples/third_party/rsl_rl && sha256sum -c SHA256SUMS

